import 'package:flutter/material.dart';
import 'splash1.dart';
import 'signin.dart'; // Create this page or any next screen

void main() {
  runApp(const JobSahiApp());
}

class JobSahiApp extends StatelessWidget {
  const JobSahiApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Job Sahi',
      debugShowCheckedModeBanner: false,
      home: const Splash1(),
    );
  }
}
