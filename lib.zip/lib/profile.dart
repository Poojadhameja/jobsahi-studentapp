import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: CompleteProfileScreen(),
  ));
}

/// Profile Avatar + Edit Widget
class ProfileAvatarEdit extends StatelessWidget {
  final VoidCallback onEdit;

  const ProfileAvatarEdit({super.key, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 110,
          height: 110,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            color: Color(0xFFE0ECF6),
          ),
          child: const Icon(
            Icons.person,
            size: 60,
            color: Color(0xFF144B75),
          ),
        ),
        const SizedBox(height: 10),
        ElevatedButton.icon(
          onPressed: onEdit,
          icon: const Icon(Icons.edit, size: 16, color: Colors.white),
          label: const Text(
            "Edit",
            style: TextStyle(fontSize: 14, color: Colors.white),
          ),
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF3D7CA4),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(6),
            ),
            elevation: 0,
          ),
        ),
      ],
    );
  }
}

class CompleteProfileScreen extends StatefulWidget {
  const CompleteProfileScreen({super.key});

  @override
  State<CompleteProfileScreen> createState() => _CompleteProfileScreenState();
}

class _CompleteProfileScreenState extends State<CompleteProfileScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  String selectedGender = 'Male';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Align(
                alignment: Alignment.topLeft,
                child: CircleAvatar(
                  backgroundColor: const Color(0xFFF0F5FA),
                  child: IconButton(
                    icon: const Icon(Icons.arrow_back, color: Color(0xFF144B75)),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "Complete Your Profile",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF144B75),
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                "आपकी जानकारी सिर्फ आपके लिए सुरक्षित है    कोई और इसे नहीं\nदेख सकता",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: Color(0xFF144B75)),
              ),
              const SizedBox(height: 25),

              /// Avatar Section from Component
              ProfileAvatarEdit(
                onEdit: () {
                  // TODO: Handle edit click
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Edit avatar clicked")),
                  );
                },
              ),

              const SizedBox(height: 15),

              Align(
                alignment: Alignment.centerLeft,
                child: RichText(
                  text: const TextSpan(
                    text: 'Name',
                    style: TextStyle(color: Color(0xFF144B75), fontSize: 14),
                    children: [
                      TextSpan(text: ' *', style: TextStyle(color: Colors.red)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 6),
              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  hintText: "नाम",
                  filled: true,
                  fillColor: const Color(0xFFF0F5FA),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                ),
              ),
              const SizedBox(height: 20),

              Align(
                alignment: Alignment.centerLeft,
                child: RichText(
                  text: const TextSpan(
                    text: 'Phone Number',
                    style: TextStyle(color: Color(0xFF144B75), fontSize: 14),
                    children: [
                      TextSpan(text: ' *', style: TextStyle(color: Colors.red)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Container(
                    width: 70,
                    height: 55,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF0F5FA),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Center(
                      child: Text(
                        "+91",
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: phoneController,
                      keyboardType: TextInputType.phone,
                      decoration: InputDecoration(
                        hintText: "मोबाइल नंबर",
                        filled: true,
                        fillColor: const Color(0xFFF0F5FA),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),

              Align(
                alignment: Alignment.centerLeft,
                child: RichText(
                  text: const TextSpan(
                    text: 'Gender',
                    style: TextStyle(color: Color(0xFF144B75), fontSize: 14),
                    children: [
                      TextSpan(text: ' *', style: TextStyle(color: Colors.red)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  genderOption("Male"),
                  const SizedBox(width: 16),
                  genderOption("Female"),
                  const SizedBox(width: 16, ),
                  genderOption("Other"),
                ],
              ),
              const SizedBox(height: 60),

              SizedBox(
                width: double.infinity,
                height: 48,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const CompleteProfileScreen()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6BAF46),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(6),
                    ),
                    elevation: 2,
                  ),
            child: const Text("Next",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget genderOption(String gender) {
    return Row(
      children: [
        Radio<String>(
          value: gender,
          groupValue: selectedGender,
          activeColor: const Color(0xFF144B75),
          onChanged: (val) {
            setState(() {
              selectedGender = val!;
            });
          },
        ),
        Text(gender),
      ],
    );
  }
}
