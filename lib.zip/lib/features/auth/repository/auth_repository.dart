import 'dart:convert'; // ✅ for jsonEncode
import 'package:flutter/foundation.dart';
import 'package:dio/dio.dart';
import '../../../shared/services/api_service.dart';
import '../../../shared/services/token_storage.dart';
import '../../../core/utils/app_constants.dart';

/// Abstract interface for authentication repository
abstract class AuthRepository {
  Future<CreateAccountResponse> createAccount({
    required String name,
    required String email,
    required String phone,
    required String password,
  });

  Future<LoginResponse> login({
    required String email,
    required String password,
  });

  Future<LoginResponse> loginWithOtp({required String phoneNumber});

  Future<LoginResponse> verifyOtp({
    required String phoneNumber,
    required String otp,
  });

  Future<bool> logout();
  Future<bool> isLoggedIn();
  Future<User?> getCurrentUser();
}

/// Implementation of AuthRepository
class AuthRepositoryImpl implements AuthRepository {
  final ApiService _apiService;
  final TokenStorage _tokenStorage;

  AuthRepositoryImpl({
    required ApiService apiService,
    required TokenStorage tokenStorage,
  }) : _apiService = apiService,
       _tokenStorage = tokenStorage;

  @override
  Future<CreateAccountResponse> createAccount({
    required String name,
    required String email,
    required String phone,
    required String password,
  }) async {
    try {
      debugPrint('Creating account for: $email');

      // ✅ Prepare request data as JSON
      final requestData = {
        'name': name,
        'email': email,
        'phone_number': phone,
        'password': password,
        'role': AppConstants.studentRole,
      };

      debugPrint(
        'Sending request to: ${AppConstants.baseUrl}${AppConstants.createUserEndpoint}',
      );
      debugPrint('Request data: $requestData');

      // ✅ Send JSON body
      final response = await _apiService.post(
        AppConstants.createUserEndpoint,
        data: jsonEncode(requestData),
      );

      debugPrint('API Response Status: ${response.statusCode}');
      debugPrint('API Response Data: ${response.data}');

      final responseData = response.data;
      final createAccountResponse = CreateAccountResponse.fromJson(
        responseData,
      );

      // If account creation is successful, store user data
      if (createAccountResponse.success && createAccountResponse.user != null) {
        final user = createAccountResponse.user!;
        await _tokenStorage.storeLoginSession(
          token: responseData['token'] ?? '',
          userId: user.id,
          email: user.email,
          name: user.name,
          phone: user.phone,
        );

        if (responseData['token'] != null) {
          _apiService.setAuthToken(responseData['token']);
        }
      }

      return createAccountResponse;
    } catch (e) {
      debugPrint('Error creating account: $e');
      return CreateAccountResponse(
        success: false,
        message: 'Account creation failed: ${e.toString()}',
      );
    }
  }

  @override
  Future<LoginResponse> login({
    required String email,
    required String password,
  }) async {
    try {
      debugPrint('=== LOGIN API CALL START ===');
      debugPrint('Logging in user: $email');
      debugPrint(
        'Request URL: ${AppConstants.baseUrl}${AppConstants.loginEndpoint}',
      );

      final requestData = {'email': email, 'password': password};
      debugPrint('Request Data: $requestData');
      debugPrint('Request Data JSON: ${jsonEncode(requestData)}');

      final response = await _apiService.post(
        AppConstants.loginEndpoint,
        data: jsonEncode(requestData), // ✅ send JSON
      );

      debugPrint('API Response Status: ${response.statusCode}');
      debugPrint('API Response Headers: ${response.headers}');
      debugPrint('API Response Data: ${response.data}');
      debugPrint('API Response Data Type: ${response.data.runtimeType}');

      // Additional debugging for response structure
      if (response.data != null) {
        debugPrint('Response data toString(): ${response.data.toString()}');
        if (response.data is String) {
          debugPrint(
            'Response string length: ${(response.data as String).length}',
          );
        }
      }

      // Handle different response formats
      Map<String, dynamic> responseData;

      if (response.data is Map<String, dynamic>) {
        responseData = response.data as Map<String, dynamic>;
        debugPrint('Response is Map<String, dynamic>');
      } else if (response.data is String) {
        debugPrint('Response is String, attempting to parse as JSON');
        // If response is a string, try to parse it as JSON
        try {
          responseData =
              jsonDecode(response.data as String) as Map<String, dynamic>;
          debugPrint('Successfully parsed string as JSON');
        } catch (e) {
          debugPrint('Failed to parse response string as JSON: $e');
          debugPrint('Raw string response: ${response.data}');
          return LoginResponse(
            success: false,
            message: 'Invalid response format from server: ${response.data}',
          );
        }
      } else {
        debugPrint(
          'Unexpected response data type: ${response.data.runtimeType}',
        );
        debugPrint('Raw response data: ${response.data}');
        return LoginResponse(
          success: false,
          message: 'Unexpected response format from server: ${response.data}',
        );
      }

      debugPrint('Parsed Response Data: $responseData');
      debugPrint('Response Data Keys: ${responseData.keys.toList()}');

      // Check for various success indicators
      bool isSuccess = false;
      String successMessage = 'Login response received';
      String? token;
      User? user;

      // Try different success indicators
      if (responseData['success'] == true) {
        isSuccess = true;
        debugPrint('Success found in "success" field');
      } else if (responseData['status'] == 'success') {
        isSuccess = true;
        debugPrint('Success found in "status" field');
      } else if (responseData['status'] == '200') {
        isSuccess = true;
        debugPrint('Success found in "status" field with value 200');
      } else if (responseData['code'] == 200) {
        isSuccess = true;
        debugPrint('Success found in "code" field with value 200');
      } else if (responseData['error'] == false) {
        isSuccess = true;
        debugPrint('Success found in "error" field as false');
      } else if (responseData.containsKey('token') &&
          responseData['token'] != null) {
        isSuccess = true;
        debugPrint('Success found because token exists');
      }

      // Extract message
      successMessage =
          responseData['message'] ??
          responseData['msg'] ??
          responseData['error_message'] ??
          responseData['description'] ??
          'Login response received';

      // Extract token
      token =
          responseData['token'] ??
          responseData['access_token'] ??
          responseData['auth_token'] ??
          responseData['jwt'];

      // Extract user data
      if (responseData['user'] != null) {
        try {
          user = User.fromJson(responseData['user']);
          debugPrint('User data extracted successfully');
        } catch (e) {
          debugPrint('Failed to parse user data: $e');
        }
      }

      debugPrint(
        'Final Login Response - Success: $isSuccess, Message: $successMessage, Token: ${token != null ? "Present" : "Missing"}',
      );

      // If we still don't have success but got a 200 status, let's try a different approach
      if (!isSuccess && response.statusCode == 200) {
        debugPrint(
          '200 status but no success indicator found, checking if response contains any positive indicators...',
        );

        // Check if response contains any positive indicators
        if (responseData.isNotEmpty) {
          debugPrint('Response is not empty, treating as success for now');
          isSuccess = true;
          successMessage = 'Login successful (200 status)';
        }
      }

      // Create LoginResponse
      final loginResponse = LoginResponse(
        success: isSuccess,
        message: successMessage,
        token: token,
        user: user,
      );

      debugPrint('=== FINAL LOGIN RESPONSE ===');
      debugPrint('Success: ${loginResponse.success}');
      debugPrint('Message: ${loginResponse.message}');
      debugPrint(
        'Token: ${loginResponse.token != null ? "Present" : "Missing"}',
      );
      debugPrint('User: ${loginResponse.user != null ? "Present" : "Missing"}');
      debugPrint('=== LOGIN API CALL END ===');

      if (loginResponse.success && loginResponse.token != null) {
        // Store token even if user data is not available
        await _tokenStorage.storeLoginSession(
          token: loginResponse.token!,
          userId: loginResponse.user?.id ?? '',
          email: loginResponse.user?.email ?? email,
          name: loginResponse.user?.name ?? '',
          phone: loginResponse.user?.phone ?? '',
        );

        _apiService.setAuthToken(loginResponse.token!);
        debugPrint('Login successful, token stored');
      } else if (loginResponse.success && loginResponse.token == null) {
        debugPrint('Login successful but no token received');
      }

      return loginResponse;
    } catch (e) {
      debugPrint('Error logging in: $e');
      debugPrint('Error type: ${e.runtimeType}');
      return LoginResponse(
        success: false,
        message: 'Login failed: ${e.toString()}',
      );
    }
  }

  @override
  Future<LoginResponse> loginWithOtp({required String phoneNumber}) async {
    try {
      debugPrint('Sending OTP to: $phoneNumber');

      final requestData = {'phone': phoneNumber};

      final response = await _apiService.post(
        '/auth/send_otp.php',
        data: jsonEncode(requestData), // ✅ send JSON
      );

      debugPrint('OTP API Response Status: ${response.statusCode}');
      debugPrint('OTP API Response Data: ${response.data}');

      final responseData = response.data;

      return LoginResponse(
        success: responseData['success'] ?? false,
        message: responseData['message'] ?? 'OTP sent successfully',
      );
    } catch (e) {
      debugPrint('Error sending OTP: $e');
      return LoginResponse(
        success: false,
        message: 'Failed to send OTP: ${e.toString()}',
      );
    }
  }

  @override
  Future<LoginResponse> verifyOtp({
    required String phoneNumber,
    required String otp,
  }) async {
    try {
      debugPrint('Verifying OTP for: $phoneNumber');

      final requestData = {'phone': phoneNumber, 'otp': otp};

      final response = await _apiService.post(
        '/auth/verify_otp.php',
        data: jsonEncode(requestData), // ✅ send JSON
      );

      debugPrint(
        'OTP Verification API Response Status: ${response.statusCode}',
      );
      debugPrint('OTP Verification API Response Data: ${response.data}');

      final responseData = response.data;
      final loginResponse = LoginResponse.fromJson(responseData);

      if (loginResponse.success &&
          loginResponse.user != null &&
          loginResponse.token != null) {
        final user = loginResponse.user!;
        await _tokenStorage.storeLoginSession(
          token: loginResponse.token!,
          userId: user.id,
          email: user.email,
          name: user.name,
          phone: user.phone,
        );

        _apiService.setAuthToken(loginResponse.token!);
      }

      return loginResponse;
    } catch (e) {
      debugPrint('Error verifying OTP: $e');
      return LoginResponse(
        success: false,
        message: 'OTP verification failed: ${e.toString()}',
      );
    }
  }

  @override
  Future<bool> logout() async {
    try {
      await _tokenStorage.clearAll();
      _apiService.clearAuthToken();
      debugPrint('User logged out successfully');
      return true;
    } catch (e) {
      debugPrint('Error during logout: $e');
      return false;
    }
  }

  @override
  Future<bool> isLoggedIn() async {
    try {
      final isLoggedIn = await _tokenStorage.isLoggedIn();
      final hasToken = await _tokenStorage.hasToken();

      if (isLoggedIn && !hasToken) {
        await _tokenStorage.clearAll();
        return false;
      }

      return isLoggedIn && hasToken;
    } catch (e) {
      debugPrint('Error checking login status: $e');
      return false;
    }
  }

  @override
  Future<User?> getCurrentUser() async {
    try {
      final isLoggedIn = await this.isLoggedIn();
      if (!isLoggedIn) return null;

      final userId = await _tokenStorage.getUserId();
      final email = await _tokenStorage.getUserEmail();
      final name = await _tokenStorage.getUserName();
      final phone = await _tokenStorage.getUserPhone();

      if (userId == null || email == null || name == null || phone == null) {
        return null;
      }

      return User(id: userId, name: name, email: email, phone: phone);
    } catch (e) {
      debugPrint('Error getting current user: $e');
      return null;
    }
  }

  /// Test method to debug API response
  Future<void> testLoginAPI(String email, String password) async {
    try {
      debugPrint('=== TESTING LOGIN API ===');
      debugPrint('Email: $email');
      debugPrint('Password: $password');

      final requestData = {'email': email, 'password': password};
      debugPrint('Request Data: $requestData');

      final response = await _apiService.post(
        AppConstants.loginEndpoint,
        data: jsonEncode(requestData),
      );

      debugPrint('=== RAW API RESPONSE ===');
      debugPrint('Status Code: ${response.statusCode}');
      debugPrint('Headers: ${response.headers}');
      debugPrint('Data Type: ${response.data.runtimeType}');
      debugPrint('Data: ${response.data}');
      debugPrint('Data toString(): ${response.data.toString()}');
      debugPrint('=== END RAW RESPONSE ===');
    } catch (e) {
      debugPrint('=== API TEST ERROR ===');
      debugPrint('Error: $e');
      debugPrint('Error Type: ${e.runtimeType}');
      debugPrint('=== END API TEST ERROR ===');
    }
  }
}
